<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\StudentMark;
use App\Models\Student;

class StudentMarkController extends Controller
{

    public function index()
    {
        $studentMarks = StudentMark::with('student')->orderBy('created_at', 'desc')->paginate(5);
        return view('students.marks.index', compact('studentMarks'));
    }
    public function create()
    {
        $students = Student::all();
        return view('students.marks.create', compact('students'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'student_id' => 'required|exists:students,id',
            'term' => 'required|string',
            'maths' => 'required|integer|min:0',
            'science' => 'required|integer|min:0',
            'history' => 'required|integer|min:0',
        ]);

      
        $totalMarks = $request->input('maths') + $request->input('science') + $request->input('history');

        StudentMark::create([
            'student_id' => $request->input('student_id'),
            'term' => $request->input('term'),
            'maths' => $request->input('maths'),
            'science' => $request->input('science'),
            'history' => $request->input('history'),
            'total_marks' => $totalMarks,
        ]);

        return redirect()->route('student.marks.index')->with('status', 'Student marks added successfully.');
    }
}
