<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
</head>
<body>
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Student Management System</h2>
                </div>
                <div class="pull-right mb-2">
                   <a class="btn btn-success" href="{{ route('students') }}"> Home</a>
                    <a class="btn btn-success" href="{{ route('students.create') }}"> Add Student </a>
                    <a class="btn btn-primary" href="{{ route('student.marks.create') }}">Add Student Mark</a>
                    <a class="btn btn-warning" href="{{ route('student.marks.index') }}">Student Marks List</a>

                </div>
            </div>
        </div>
        @if ($message = Session::get('success'))
            <div class="alert alert-success">
                <p>{{ $message }}</p>
            </div>
        @endif
        <h1>Student Marks List</h1>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Maths</th>
                <th>Science</th>
                <th>History</th>
                <th>Term</th>
                <th>Total Marks</th>
                <th>Created On</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        @foreach($studentMarks as $studentMark)
    <tr>
        <td>{{ $loop->iteration }}</td>
        <td>{{ $studentMark->student->std_name }}</td>
        <td>{{ $studentMark->maths }}</td>
        <td>{{ $studentMark->science }}</td>
        <td>{{ $studentMark->history }}</td>
        <td>{{ $studentMark->term }}</td>
        <td>{{ $studentMark->total_marks }}</td>
        <td>{{ $studentMark->created_at->format('M d, Y h:i A') }}</td>
        <td>
            <a class="btn btn-primary" href="#">Edit</a>
            <form action="#" method="post" style="display:inline;">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-danger">Delete</button>
            </form>
        </td>
    </tr>
@endforeach

        </tbody>
    </table>

    </div>
</body>
</html>