<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
</head>
<body>
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Student Management System</h2>
                </div>
                <div class="pull-right mb-2">
                <a class="btn btn-success" href="<?php echo e(route('students')); ?>"> Home</a>
                    <a class="btn btn-success" href="<?php echo e(route('students.create')); ?>"> Add Student </a>
                    <a class="btn btn-primary" href="<?php echo e(route('student.marks.create')); ?>">Add Student Mark</a>
                    <a class="btn btn-warning" href="<?php echo e(route('student.marks.index')); ?>">Student Marks List</a>

                </div>
            </div>
        </div>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>S.No</th>
                    <th> Name</th>
                    <th> Age </th>
                    <th>Gender</th>
                    <th>Reporting Teacher</th>
                    <th width="280px">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($student->id); ?></td>
                        <td><?php echo e($student->std_name); ?></td>
                        <td><?php echo e($student->std_age); ?></td>
                        <td><?php echo e($student->std_gender); ?></td>
                        <td><?php echo e($student->teacher->teacher_name); ?></td>
                        <td>
                            <form action="<?php echo e(route('students.destroy',$student->id)); ?>" method="Post">
                                <a class="btn btn-primary" href="<?php echo e(route('students.edit',$student->id)); ?>">Edit</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo $students->links(); ?>

    </div>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/student-management-system/resources/views/students/index.blade.php ENDPATH**/ ?>