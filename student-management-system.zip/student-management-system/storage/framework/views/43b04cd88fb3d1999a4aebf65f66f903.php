<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
</head>
<body>
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Student Management System</h2>
                </div>
                <div class="pull-right mb-2">
                   <a class="btn btn-success" href="<?php echo e(route('students')); ?>"> Home</a>
                    <a class="btn btn-success" href="<?php echo e(route('students.create')); ?>"> Add Student </a>
                    <a class="btn btn-primary" href="<?php echo e(route('student.marks.create')); ?>">Add Student Mark</a>
                    <a class="btn btn-warning" href="<?php echo e(route('student.marks.index')); ?>">Student Marks List</a>

                </div>
            </div>
        </div>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <h1>Student Marks List</h1>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Maths</th>
                <th>Science</th>
                <th>History</th>
                <th>Term</th>
                <th>Total Marks</th>
                <th>Created On</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $studentMarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentMark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($studentMark->student->std_name); ?></td>
        <td><?php echo e($studentMark->maths); ?></td>
        <td><?php echo e($studentMark->science); ?></td>
        <td><?php echo e($studentMark->history); ?></td>
        <td><?php echo e($studentMark->term); ?></td>
        <td><?php echo e($studentMark->total_marks); ?></td>
        <td><?php echo e($studentMark->created_at->format('M d, Y h:i A')); ?></td>
        <td>
            <a class="btn btn-primary" href="#">Edit</a>
            <form action="#" method="post" style="display:inline;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Delete</button>
            </form>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>

    </div>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/student-management-system/resources/views/students/marks/index.blade.php ENDPATH**/ ?>