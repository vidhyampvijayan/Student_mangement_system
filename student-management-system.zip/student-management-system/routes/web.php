<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\StudentMarkController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

//student 
Route::get('/students', [StudentController::class, 'index'])->name('students');
Route::get('/students/create', [StudentController::class, 'create'])->name('students.create');
Route::post('store', [StudentController::class, 'store'])->name('students.store');
Route::get('/students/destroy', [StudentController::class, 'destroy'])->name('students.destroy');
Route::get('/students/edit/{student}', [StudentController::class, 'edit'])->name('students.edit');
Route::put('/students/{student}', [StudentController::class, 'update'])->name('students.update');
Route::delete('/students/{student}', [StudentController::class, 'destroy'])->name('students.destroy');


//student marks
Route::get('/students/marks/create', [StudentMarkController::class, 'create'])->name('student.marks.create');
Route::post('/students/marks/store', [StudentMarkController::class, 'store'])->name('student.marks.store');
Route::get('/students/marks', [StudentMarkController::class, 'index'])->name('student.marks.index');


